package com.flp.fms.dao;

import java.util.List;
import java.util.Map;

import com.flp.fms.pojo.Category;
import com.flp.fms.pojo.Film;
import com.flp.fms.pojo.Language;

public interface IFilmDao {
	
	public List<Language> getLanguages();

	public List<Category> getCategories();
	
	public Film addFilm(Film film);
	
	public List<Film> getAllFilms();
	
	public int removeFilm(int id);

	public List<Film> searchFilm(Film film);

	public Film updateFilm(int id);
	
	public int updatedFilm(int id, Film film);
	
	

	
	
}
