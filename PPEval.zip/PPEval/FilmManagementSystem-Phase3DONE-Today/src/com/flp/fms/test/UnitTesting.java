package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.experimental.categories.Categories;

import com.flp.fms.dao.FilmDaoImplForDataBase;
import com.flp.fms.pojo.Actor;
import com.flp.fms.pojo.Category;
import com.flp.fms.pojo.Film;
import com.flp.fms.pojo.Language;
import com.flp.service.ActorServiceImplDataBase;
import com.flp.service.FilmServiceImplDataBase;
import com.sun.accessibility.internal.resources.accessibility;

public class UnitTesting {

	FilmServiceImplDataBase filmService=new FilmServiceImplDataBase();
	ActorServiceImplDataBase actorService=new ActorServiceImplDataBase();
//1
	/*@Test
	public void testToGetLanguages(){
		
		List<Language> languages=new ArrayList<>();
		
		languages.add(new Language(1, "Hindi"));
		languages.add(new Language(2, "English"));
		languages.add(new Language(3, "Marathi"));
		languages.add(new Language(4, "Gujarati"));
		languages.add(new Language(5, "Tamil"));
		languages.add(new Language(6, "Telegu"));
		languages.add(new Language(7, "Punjabi"));
		assertEquals(languages, filmService.getLanguages());
	}*/
	
//2
	/*@Test
	public void testToGetLanguagesIfNotSame(){
		
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "Chinese"));
		languages.add(new Language(2, "Swedish"));
		languages.add(new Language(3, "Japanese"));
		languages.add(new Language(4, "Korean"));
		languages.add(new Language(5, "German"));
		languages.add(new Language(6, "French"));
		languages.add(new Language(7, "Hebrew"));
		assertNotEquals(languages, filmService.getLanguages());
	}*/

//3	
	/*@Test
	public void testToGetCategories(){
		
		List<Category> category=new ArrayList<>();
		
		category.add(new Category(1,"Animation"));
		category.add(new Category(2,"Classic"));
		category.add(new Category(3,"Epic"));
		category.add(new Category(4,"Family"));
		category.add(new Category(5,"Gamic"));
		category.add(new Category(6,"Sci-Fi"));
		category.add(new Category(7,"Cartoon"));
		assertEquals(category, filmService.getCategories());
	}*/

//4	
	/*@Test
	public void testToGetNoCategories(){
		
		List<Category> category=new ArrayList<>();
		category.add(new Category(1,"Horror"));
		category.add(new Category(2,"Comedy"));
		category.add(new Category(3,"Romance"));
		category.add(new Category(4,"Action"));
		category.add(new Category(5,"Drama"));
		category.add(new Category(6,"Bio-Pic"));
		category.add(new Category(7,"Documentary"));
		assertNotEquals(category, filmService.getCategories());
	}*/
	
//5
	/*@Test
	public void testToAddFilm(){
		
		Film film=new Film();
		List<Film> resfilm=new ArrayList<>();
		
		film.setFilm_ID(7);
		film.setTitle("Dilwale");
		film.setDescription("SuperHit");
		film.setReleaseYear(new Date("07-apr-2016"));
		film.setOriginalLanguage(new Language(1,"Hindi"));
		film.setRentalDuration(new Date("14-apr-2016"));
		film.setLength(150);
		film.setReplacementCost((double) 20000);
		film.setRatings(5);
		film.setSpecialFeatures("Action");
		film.setCategory(new Category(3, "Romance"));
		
		Set<Actor> actors=new HashSet<>();
		Actor actor=new Actor();
		actor.setActor_Id(1);
		Actor actor2=new Actor();
		actor2.setActor_Id(2);
		actors.add(actor);
		actors.add(actor2);
		film.setActors(actors);
		
		List<Language> otherlangs=new ArrayList<>();
		Language lang=new Language();
		lang.setLanguage_Id(1);
		Language lang2=new Language();
		lang2.setLanguage_Id(2);
		otherlangs.add(lang);
		otherlangs.add(lang2);
		film.setLanguages(otherlangs);
		
		
		
		assertEquals(film, filmService.addFilm(film));
		
		
	}*/
	

//6	
	/*@Test
	public void testActorObjectNull(){
		
		Actor actor=null;
		assertEquals(actor,null);
		
	}*/
	
//7
	/*@Test
	public void testForFilmObjectIsNull()
	{
		Film film=null;
		assertNull(film);
		
	}*/
	
//8
	/*@Test
	public void testForDeleteFilm(){
		
		Film film=new Film();
		film.setTitle("Dilwale");
		film.setDescription("SuperHit BlockBuster");
		Date release_Year=new Date("07-Apr-2016");
		film.setReleaseYear(release_Year);
		
		Language lang=new Language();
    	lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		
		Date d1=new Date("27-apr-2016");
		film.setRentalDuration(d1);
		film.setLength(150);
		film.setReplacementCost((double) 20000);
		film.setRatings(5);
		film.setSpecialFeatures("Action");
		
		Category category=new Category();
		category.setCategory_Id(3);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
    	langs.add(lang1);
    	Language lang2=new Language();
    	lang2.setLanguage_Id(4);
    	langs.add(lang2);
		film.setLanguages(langs);
	
		Set<Actor> actors=new HashSet<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		actors.add(actor1);
    	film.setActors(actors);
    	
		assertEquals(1,filmService.removeFilm(6));
	}*/

	
//9 
	/*@Test
	public void testForUpdatedFilm(){
		
		List<Film> filmList=new ArrayList<>();
		Film film=new Film();
		//film.setFilm_ID(8);
		film.setTitle("Dilwale");
		film.setDescription("SuperHit");
		Date release_Year=new Date("07-Apr-2016");
		film.setReleaseYear(release_Year);
		film.setRentalDuration(new Date("14-apr-2016"));
		film.setReleaseYear(new Date("07-apr-2016"));
		Language lang=new Language();
    	lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		
		Date d1=new Date("14-Apr-2016");
		film.setRentalDuration(d1);
		film.setLength(150);
		film.setReplacementCost((double) 20000);
		film.setRatings(5);;
		film.setSpecialFeatures("Action");
		
		Category category=new Category();
		category.setCategory_Id(3);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
    	langs.add(lang1);
		film.setLanguages(langs);
	
		Set<Actor> actors=new HashSet<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		actors.add(actor1);
		Actor actor2=new Actor();
		actor2.setActor_Id(2);
		actors.add(actor2);
		film.setActors(actors);
		
		assertEquals(1, filmService.updatedFilm(1, film));
		
		
	}*/
	
//10
	/*
	@Test
	public void testForAddActor(){
		
		Actor actor=new Actor();
		actor.setFirst_Name("ShahRukh");
		actor.setLast_Name("Khan");
		assertEquals(1,actorService.addActor(actor));
		
	}*/
	
//11
	/*@Test
	public void testForSearchActorNotSame(){
		
		Actor actor=new Actor();
		actor.setFirst_Name("Shahrukh");
		actor.setLast_Name("Khan");
		assertNotEquals(actor,actorService.searchActorById(30));
		
	}
	*/
	
//12

	/*@Test
	public void testForSearchActor(){
		
		Actor actor=new Actor();
		actor.setFirst_Name("Shah Rukh");
		actor.setLast_Name("Khan");
		assertNotEquals(actor,actorService.searchActorById(30));
		
	}
	*/
	
//13
	/*@Test
	public void testForDeleteActor(){
		
		assertEquals(1,actorService.removeActor(8) );
		
	}*/
}
