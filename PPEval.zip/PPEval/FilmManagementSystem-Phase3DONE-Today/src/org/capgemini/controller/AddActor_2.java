package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.flp.fms.pojo.Actor;

import com.flp.service.ActorServiceImplDataBase;

/**
 * Servlet implementation class AddActor_2
 */
public class AddActor_2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		ActorServiceImplDataBase actorService=new ActorServiceImplDataBase();
		Actor actor=new Actor();
		
		//Set The Details to Actor Object 
		String fname=request.getParameter("ActorFirstname");
		actor.setFirst_Name(fname);
		String lname=request.getParameter("ActorLastName");
		actor.setLast_Name(lname);
		
		//Calling the Add Actor Method and Saving the Actor Object in DB
		int count=actorService.addActor(actor);
		if(count==1){
			out.println("<head>");
			out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
			out.println("</head>");
			out.println("<body><br/><br/><br/><h2><center>Actor added successfully!!!!!</center></h2></body>");
		}
		
		
	}

}
