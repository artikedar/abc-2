package com.flp.fms.dao;

import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {

	Set<Actor> getActors();
	
	
}
