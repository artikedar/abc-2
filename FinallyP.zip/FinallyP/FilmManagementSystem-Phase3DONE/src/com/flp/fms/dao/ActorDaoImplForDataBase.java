package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.flp.fms.pojo.Actor;

public class ActorDaoImplForDataBase implements IActorDao{
	
	public Connection getConnection(){
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmdb", "root", "Pass1234");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	@Override
	public Set<Actor> getActors() {
		Set<Actor> actors=new HashSet<>();
		Connection con=getConnection();
		String sql="SELECT * FROM actors";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				Actor actor=new Actor();
				
				actor.setActor_Id(rs.getInt(1));
				actor.setFirst_Name(rs.getString(2));
				actor.setLast_Name(rs.getString(3));
				
				actors.add(actor);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		/*actors.add(new Actor(101, "Shahrukh", "Khan", 0));
		actors.add(new Actor(102, "Amir", "Khan", 0));
		actors.add(new Actor(103, "Salman", "Khan", 0));
		actors.add(new Actor(104, "SaifAli", "Khan", 0));
		actors.add(new Actor(105, "Irrfan", "Khan", 0));
		*/
		return actors;
	}

	@Override
	public int addActor(Actor actor) {
		int count=0;
		Connection con=getConnection();
		String sql="insert into actors(firstName,lastName)"+"values(?,?)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getFirst_Name());
			pst.setString(2, actor.getLast_Name());
			count=pst.executeUpdate();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int removeActor(int id) {
		int count=0;
		Connection con=getConnection();
		String sql="delete from actors where actorId=?";
		String sql2="delete from film_actors where actorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			count=pst.executeUpdate();
			PreparedStatement pst2=con.prepareStatement(sql2);
			pst2.setInt(1, id);
			count=pst2.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}

	@Override
	public Actor searchActorById(int id) {
		Actor actor=new Actor();
		Connection con=getConnection();
		String sql="select * from actors where actorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				actor.setFirst_Name(rs.getString(2));
				actor.setLast_Name(rs.getString(3));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	@Override
	public int updateActor(Actor actor, int id) {
		int count=0;
		Connection con=getConnection();
		String sql="update actors set firstName=?,lastName=? where actorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getFirst_Name());
			pst.setString(2, actor.getLast_Name());
			pst.setInt(3, actor.getActor_Id());
			count=pst.executeUpdate();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return count;
	}
	

}
