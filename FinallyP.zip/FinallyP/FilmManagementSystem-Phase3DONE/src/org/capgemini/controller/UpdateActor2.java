package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.pojo.Actor;
import com.flp.service.ActorServiceImplDataBase;

/**
 * Servlet implementation class UpdateActor2
 */
public class UpdateActor2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		ActorServiceImplDataBase actorService=new ActorServiceImplDataBase();
		int actorId=Integer.parseInt(request.getParameter("id"));
		Actor actor=actorService.searchActorById(actorId);
		
		out.println("<html>");
		out.println("<head>");
		out.println("<script type='text/javascript' src='scripts/validate.js'></script>"
				+ " <link rel='stylesheet' type='text/css' href='css/MyStyle.css'>");
		out.println("</head>");
		
		out.println("<body>");
		out.println("<form name='actor' method='post' action='UpdateActor3'>");
		
		out.println(
				 "<table>"
				 + "<th>Create New Actor</th>"
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aFName' onmouseout='return validateDetails()' value='"+actor.getFirst_Name()+"'>"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aLName' onmouseout='return validateDetails()' value='"+actor.getLast_Name()+"'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>"
				+ " <tr><td><input type='hidden' name='actor_id' value='"+actorId+"'");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
		
	}

}
