package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.dao.FilmDaoImplForDataBase;
import com.flp.fms.pojo.Actor;
import com.flp.service.ActorServiceImplDataBase;

/**
 * Servlet implementation class UpdateActor3
 */
public class UpdateActor3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		ActorServiceImplDataBase actorService=new ActorServiceImplDataBase();
		int actorId=Integer.parseInt(request.getParameter("actor_id"));
		Actor actor=new Actor();
		
		actor.setFirst_Name(request.getParameter("aFName"));
		actor.setLast_Name(request.getParameter("aLName"));
		int count=actorService.updateActor(actor,actorId);
		out.println("<html>"
				+ "<body>");
		//out.println(count);
		if(count>0)
		{
			response.sendRedirect("UpdateActor1");
		//request.getRequestDispatcher("UpdateFilm1").forward(request, response);
		}
		out.println(
				 "</body>"
				+ "</html>");
		
	}

}
