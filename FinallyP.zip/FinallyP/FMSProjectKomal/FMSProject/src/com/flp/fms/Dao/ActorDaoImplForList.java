package com.flp.fms.Dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao{

	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		actor.add(new Actor(1, "Akshay", "Kumar"));
		actor.add(new Actor(2, "Shahid", "Kapur"));
		actor.add(new Actor(3, "Shaharukh", "Khan"));
		actor.add(new Actor(4, "Kareena", "Kapoor"));
		actor.add(new Actor(5, "Aishwarya", "Ray"));
		actor.add(new Actor(6, "Deepika", "Padukon"));
		
		
		return actor;
	}

	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return getActorList();
	}

}
