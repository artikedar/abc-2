package com.flp.fms.domain;

public class Category {
	//Private fields
	private int category_Id;
	private String category_Name;
	
	
	//No Argument Constructor
	public Category() {
		super();
	}
	
	//Paramterized Constructor
	public Category(int category_Id, String category_Name) {
		super();
		this.category_Id = category_Id;
		this.category_Name = category_Name;
	}
	
	
	//Getters and setters
	public int getCategory_Id() {
		return category_Id;
	}
	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}
	public String getCategory_Name() {
		return category_Name;
	}
	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}
	
	//Overriden toString(0 method
	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_Name=" + category_Name + "]";
	}
	
	
	

}
