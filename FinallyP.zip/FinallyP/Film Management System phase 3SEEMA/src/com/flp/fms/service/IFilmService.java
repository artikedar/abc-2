package com.flp.fms.service;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	public List<Language> getLanguages();
	public List<Category> getCategory();
	
	public Film addFilm(Film film);
	
	public List<Film> getAllFilms();
		
		
	public int removeFilm(int id);
	public List<Film> searchFilm(Film film);
	public Film updateRecord(int fID);
	public int updateFilm(int id,Film film);
	
}
