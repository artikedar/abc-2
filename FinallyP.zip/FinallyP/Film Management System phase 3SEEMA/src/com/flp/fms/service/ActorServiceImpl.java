package com.flp.fms.service;

import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForDatabase;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService{
	
	private IActorDao actorDao=new ActorDaoImplForDatabase();
	@Override
	public Set<Actor> getActors() {
	
		return actorDao.getActors();
	}
	@Override
	public int addActor(Actor actor) {
		
		return actorDao.addActor(actor);
	}
	@Override
	public int removeActor(int id) {
	
		return actorDao.removeActor(id);
	}
	@Override
	public Actor searchActorByID(int id) {
		
		return actorDao.searchActorByID(id);
	}
	@Override
	public int updateActor(Actor actor, int actorId) {
		
		return actorDao.updateActor(actor, actorId);
	}
	

}
