package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;


public class CreateFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		FilmServiceImpl filmserviceimpl=new FilmServiceImpl();
		ActorServiceImpl actorserviceimpl=new ActorServiceImpl();
		
		
		List<Language> langaugeList=filmserviceimpl.getLanguages();
		
		List<Category> category=filmserviceimpl.getCategory();
		
		out.print("<html>");
		out.print("<body>");

		out.print("<head>"
				
			+"<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"	
			+ "<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
			+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
			+ "<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
			+ "<script type='text/javascript' src='script/FormValidation.js'></script>"
			+ "<link type='text/css' rel='stylesheet' href='css/MyStyle.css'>"
			+ "<script>$(function() {$( '#datepicker' ).datepicker();});</script>"
			+ "<script>$(function() {$( '#datepicker1' ).datepicker();});</script>"
			+ "<script>$(document).ready(function() {$('#start_datepicker')datepicker();$('#end_datepicker').datepicker();});</script>"
			+ "</head>");
		out.print("<form name='film' method='post'action='AddFilm'>");
		out.print("<h1 align='center'>Add Film Details</h1>");
		out.println("<table>" + 
				"<tr>" +
				"<td>Film Title:</td>" +
				"<td><input type='text' name='title' onmouseout='return isValidTitle()'>" +
				"<div id='titleDiv'class='errMsg'></div></td>" +
				"</tr>");
		out.print("<tr>" 
				+ "<td>Desciption:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25'></textarea></td><"
				+ "/tr>");
		out.println("<tr>" +
				"<td>Release Year:</td>" +
				"<td><input type='text' name='releaseYear' id='datepicker'></td>" +
						"</tr>");
		out.print("<tr><td>Original Language:</td>"
				+ "<td><select name='originalLang'>");
		for(Language lang:langaugeList){
			out.print("<option value="+lang.getLanguage_Id()+">"+lang.getLanguage_Name()+"</option>");
			}
		out.print("</select></td></tr>");
		
		out.println("<tr>" +
				"<td>Rental Duration:</td>" +
				"<td><input type='text' name='rentalduration'id='datepicker1'onmouseout='return isValidateRentalDuration()'>" +
				"<div id='renDur_Div' class='errMsg'></div></td>" +
						"</tr>");
		
		out.print("<tr>"
				+ "<td>Length Of Film:</td>"
				+ "<td><input type='text' name='length' size='20' onmouseout='return isValidLength()'>" +
				"<div id='lengthDiv' class='errMsg'></div></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Replacement Cost:</td>"
				+ "<td><input type='text' name='cost' size='20' class='text' onmouseout='return  replacementCostValidation()'>" +
				"<div id='replacementDiv' class='errMsg'></div></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Ratings:</td>"
				+ "<td><select name='rating'>"
				+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</select></td>"
				+ "</tr>");
		
		
		out.print("<tr>"
				+ "<td>Special Features:</td>"
				+ "<td><input type='text' name='specialFeatures' onmouseout='return isValidSpecialFeatures()'>"
				+ "<div id='specialFeaturesDiv' class='errMsg'></div></td>"
				+ "</tr>");
		
		out.print("<tr><td>Category:</td>"
				+ "<td><select name='category'>");
		
		for(Category categorys:category){
			out.print("<option value="+categorys.getCategory_Id()+">"+categorys.getCategory_Name()+"</option>");
		}
		
		
		
		Set<Actor> actor=actorserviceimpl.getActors();
		out.print("</select></td></tr>");

		out.print("<tr><td>Actor:</td>"
				+ "<td><select name='actor' multiple='' >");
		for(Actor actors:actor){
			out.print("<option value="+actors.getActor_Id()+">"+actors.getActor_First_Name()+"</option>");
			}
		out.print("</select></td></tr>");

		
		
		out.print("<tr><td>Language:</td>"
				+ "<td><select multiple name='Lang'  >");
		for(int i=0;i<langaugeList.size(); i++){
			Language language1=langaugeList.get(i);
			out.print("<option value='"+ language1.getLanguage_Id()+"'>" + language1.getLanguage_Name()+"</option>");
		}
		out.print("</select></td></tr>");
	
		
		out.print("<tr><td></td>"
				+ "<td><input class='myBtn' type='submit' value='Save'</td>"
				+ "<td><input class='myBtn' type='reset' value='Clear'</td>"
			+ "</tr>");
			
		out.print("</table></form>");
		out.print("</body></html>");
		
					
		
	}

}
