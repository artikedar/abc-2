package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;


public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		FilmServiceImpl filmserviceimpl=new FilmServiceImpl();
		List<Film> allFilmsList=filmserviceimpl.getAllFilms();
		
		
		out.println("<html>");
		out.println("<head>");
		out.println("<link rel='stylesheeet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		
		

		out.println("<body>"
		
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<table border=4px>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Film Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "<th>Actors</th>"
				+ "<th>Languages</th>"
				+ "<th>Delete</th>"
				+ "</tr>");
		for(Film film1:allFilmsList)
		{
			out.println("<tr>");
			out.println("<td>"+film1.getFilmId()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getRelease_Year()+"</td>");
			out.println("<td>"+film1.getOriginal_Langauges().getLanguage_Name()+"</td>");
			out.println("<td>"+film1.getRental_Duration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacement_Cost()+"</td>");
			out.println("<td>"+film1.getRating()+"</td>");
			out.println("<td>"+film1.getSpecial_Features()+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_Name()+"</td>");
			
			List<Language>langs=new ArrayList<>();
			langs=film1.getLanguages();
			out.println("<td>");
			for(Language lang:langs)
				out.println(lang.getLanguage_Name()+",");
			out.println("</td>");
			Set<Actor> actors =new HashSet<>();
			
			actors=film1.getActors();
			out.println("<td>");
			
			for(Actor act:actors)
				out.println(act.getActor_First_Name()+" "+act.getActor_Last_Name()+",");
			out.println("</td>");
			
			out.print("<td><a href='DeleteFilmServlet?FilmId="+film1.getFilmId()+"'><h5 style='color:red;''>DELETE</h5></a></td>");
			out.println("</tr>");
		}
			out.println("</table></body>");
	}

}
