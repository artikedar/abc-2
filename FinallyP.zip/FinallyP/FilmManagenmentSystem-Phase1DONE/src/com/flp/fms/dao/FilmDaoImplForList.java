package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	
	@Override
	public List<Language> getLanguages() {
			
			List<Language> languages=new ArrayList<>();
			languages.add(new Language(1, "English"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "Marathi"));
			languages.add(new Language(4, "Tamil"));
			languages.add(new Language(5, "Telegu"));
		
			return languages;
			}

	@Override
	public List<Category> getCategories() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1, "Horror"));
		categories.add(new Category(2, "Comedy"));
		categories.add(new Category(3, "Romance"));
		categories.add(new Category(4, "Drama"));
		categories.add(new Category(5, "Action"));
		categories.add(new Category(6, "Documentry"));
		
		return categories;
	}

	@Override
	public void addFilm(Film film) {
		film_Repository.put(film.getFilm_ID(), film);
		}

	@Override
	public Map<Integer, Film> getAllFilms() {
		// TODO Auto-generated method stub
		return film_Repository;
	}

	@Override
	public Film searchFilms(int filmId1) {
		Map<Integer, Film> filmList=getAllFilms();
		Collection<Film>allFilms=filmList.values();
		Film film1=new Film();
		boolean flag=false;
		for(Film film:allFilms){
			if(film.getFilm_ID()==filmId1){
				System.out.println("Film Exists:"+film);
				film1=film;
				flag=true;
				break;
			}
		}
		
		
		return film1;
	}

	@Override
	public void updateFilm(Film film1) {
		
		addFilm(film1);
		
	}

	
	
	

	
	}

	

